export class Category {
  id: number;
  catDescription: string;

  constructor(id: number, catDescription: string) {
    this.id = id;
    this.catDescription = catDescription;
  }
}
