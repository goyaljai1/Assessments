export class Assessment_cards {
  cardSTitle: string;
  cardTitle: string;
  cardDes: string;
  constructor(acardStitle: string, acardTitle: string, acardDes: string) {
    this.cardSTitle = acardStitle;
    this.cardTitle = acardTitle;
    this.cardDes = acardDes;
  }
}
